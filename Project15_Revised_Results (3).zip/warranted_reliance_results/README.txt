Project 15 warranted reliance experiments.
Thirteen primary figures and fourteen primary tables; supporting audits and predictions included.
PDF figures are vector output; PNG figures are 300 dpi; tables have CSV and PDF copies.
See metadata/captions.md for scope and assumptions. Error costs, deferral costs, reviewer (fallback) performance and review
capacity are assumed scenario values, not measurements. Revised-RQ analyses (R2_UQ_*, R4_GB_*) are exploratory revisions
after pilot feedback, not preregistered confirmatory tests. File prefixes R1-R4 follow the revised research questions;
metadata/rq_mapping.csv links each file to its legacy pilot identifier.
No human trust study or real-world deployment evaluation is claimed.
UCI source: https://doi.org/10.24432/C55S3H (CC BY 4.0); Census PUMS releases via Census.gov.
ACS task definition follows Folktables; sex, race and relationship predictors omitted.
